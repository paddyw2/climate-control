# Assignment 5 - Patrick Withams

### Directory Navigator:

src - project source code
bin - Eclipse-compiled class files
doc - javadoc html files for project
UML - UML and state diagram images
